"""
Perception Pipeline — Steps 1-3 of the semantic safety filter.

Step 1: Semantic segmentation (GroundingDINO + SAM2)
Step 2: Monocular depth estimation (Depth Anything V2)
Step 3: 3D point cloud lifting (mask × depth → per-object point clouds)

This replaces the paper's multi-view RGB-D + VI-SLAM reconstruction
with a single-image pipeline.
"""

import numpy as np
import logging
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class DetectedObject:
    """One detected object in the scene."""
    label: str
    mask: np.ndarray                # (H, W) binary mask
    bbox: np.ndarray                # [x1, y1, x2, y2]
    confidence: float
    point_cloud: Optional[np.ndarray] = None   # (N, 3) in robot base frame


@dataclass
class ScenePerception:
    """Full perception output for one image."""
    image: np.ndarray               # (H, W, 3) RGB
    depth_map: np.ndarray           # (H, W) metric depth in meters
    objects: List[DetectedObject] = field(default_factory=list)

    @property
    def labels(self) -> List[str]:
        return [obj.label for obj in self.objects]

    @property
    def point_clouds(self) -> Dict[str, np.ndarray]:
        return {obj.label: obj.point_cloud for obj in self.objects
                if obj.point_cloud is not None}


class PerceptionPipeline:
    """
    Runs the full perception stack:
      image → segmentation → depth → 3D point clouds

    Usage:
        pipeline = PerceptionPipeline(camera_intrinsics=K, T_cam_to_base=T)
        scene = pipeline.process(image, text_prompt="laptop . cup . book")
        print(scene.labels)
        for label, pc in scene.point_clouds.items():
            print(f"{label}: {pc.shape[0]} points")
    """

    def __init__(
        self,
        camera_intrinsics: np.ndarray,      # (3,3) K matrix
        T_cam_to_base: np.ndarray = None,   # (4,4) extrinsic
        depth_scale: float = 1.0,           # scale factor for monocular depth
        use_mock: bool = False,
    ):
        self.K = camera_intrinsics
        self.T_cam_to_base = T_cam_to_base if T_cam_to_base is not None \
            else np.eye(4)
        self.depth_scale = depth_scale
        self.use_mock = use_mock

        if not use_mock:
            self._load_models()

    def _load_models(self):
        """Load GroundingDINO, SAM2, and Depth Anything V2."""
        logger.info("Loading perception models...")
        # ── GroundingDINO ──
        try:
            from groundingdino.util.inference import load_model, predict
            self.gdino_predict = predict
            # Load model weights (adjust path as needed)
            # self.gdino_model = load_model(config_path, weights_path)
            logger.info("  GroundingDINO loaded")
        except ImportError:
            logger.warning("  GroundingDINO not available, will use mock")
            self.use_mock = True

        # ── SAM2 ──
        try:
            # from sam2.build_sam import build_sam2
            # from sam2.sam2_image_predictor import SAM2ImagePredictor
            logger.info("  SAM2 loaded")
        except ImportError:
            logger.warning("  SAM2 not available")

        # ── Depth Anything V2 ──
        try:
            # from depth_anything_v2.dpt import DepthAnythingV2
            logger.info("  Depth Anything V2 loaded")
        except ImportError:
            logger.warning("  Depth Anything V2 not available")

    # ─── Step 1: Segmentation ────────────────────────────────────

    def segment(
        self,
        image: np.ndarray,
        text_prompt: str,
        box_threshold: float = 0.3,
        text_threshold: float = 0.25,
    ) -> List[DetectedObject]:
        """
        Run GroundingDINO → SAM2 to get per-object masks.

        Args:
            image: (H, W, 3) RGB uint8
            text_prompt: dot-separated labels, e.g. "laptop . cup . book"
            box_threshold: GroundingDINO confidence threshold
            text_threshold: GroundingDINO text matching threshold

        Returns:
            List of DetectedObject with masks and labels
        """
        if self.use_mock:
            return self._mock_segment(image, text_prompt)

        # ── GroundingDINO detection ──
        # boxes, logits, phrases = self.gdino_predict(
        #     self.gdino_model, image, text_prompt,
        #     box_threshold=box_threshold,
        #     text_threshold=text_threshold,
        # )

        # ── SAM2 mask generation ──
        # predictor = SAM2ImagePredictor(self.sam2_model)
        # predictor.set_image(image)
        # masks, scores, _ = predictor.predict(
        #     box=boxes,
        #     multimask_output=False,
        # )

        # objects = []
        # for i, (label, mask, box, score) in enumerate(
        #     zip(phrases, masks, boxes, logits)
        # ):
        #     objects.append(DetectedObject(
        #         label=label.strip(),
        #         mask=mask.astype(bool),
        #         bbox=box.numpy(),
        #         confidence=score.item(),
        #     ))

        # return objects
        raise NotImplementedError(
            "Install GroundingDINO + SAM2 and uncomment the code above"
        )

    def _mock_segment(
        self, image: np.ndarray, text_prompt: str
    ) -> List[DetectedObject]:
        """Generate synthetic detections for testing."""
        H, W = image.shape[:2]
        labels = [l.strip() for l in text_prompt.split(".") if l.strip()]
        objects = []

        for i, label in enumerate(labels):
            # Place objects in a grid
            cx = W // (len(labels) + 1) * (i + 1)
            cy = H // 2
            half_w, half_h = 50, 40

            mask = np.zeros((H, W), dtype=bool)
            y1, y2 = max(0, cy - half_h), min(H, cy + half_h)
            x1, x2 = max(0, cx - half_w), min(W, cx + half_w)
            mask[y1:y2, x1:x2] = True

            objects.append(DetectedObject(
                label=label,
                mask=mask,
                bbox=np.array([x1, y1, x2, y2], dtype=float),
                confidence=0.9 - i * 0.05,
            ))

        return objects

    # ─── Step 2: Depth estimation ────────────────────────────────

    def estimate_depth(self, image: np.ndarray) -> np.ndarray:
        """
        Run Depth Anything V2 to get a metric-scale depth map.

        Args:
            image: (H, W, 3) RGB uint8

        Returns:
            depth_map: (H, W) float32, depth in meters
        """
        if self.use_mock:
            return self._mock_depth(image)

        # ── Depth Anything V2 ──
        # depth = self.depth_model.infer_image(image)
        # depth_metric = depth * self.depth_scale
        # return depth_metric
        raise NotImplementedError(
            "Install Depth Anything V2 and uncomment the code above"
        )

    def _mock_depth(self, image: np.ndarray) -> np.ndarray:
        """Generate synthetic depth for testing (planar desk at ~0.7m)."""
        H, W = image.shape[:2]
        # Simulate a desk surface at ~0.7m with slight gradient
        depth = np.full((H, W), 0.7, dtype=np.float32)
        # Objects are slightly closer (raised on desk)
        depth += np.random.normal(0, 0.01, (H, W)).astype(np.float32)
        return depth

    # ─── Step 3: 3D point cloud lifting ──────────────────────────

    def lift_to_3d(
        self,
        depth_map: np.ndarray,
        mask: np.ndarray,
    ) -> np.ndarray:
        """
        Back-project masked depth pixels to 3D points in the camera frame,
        then transform to robot base frame.

        Args:
            depth_map: (H, W) depth in meters
            mask: (H, W) binary mask for the object

        Returns:
            point_cloud: (N, 3) in robot base frame
        """
        fx, fy = self.K[0, 0], self.K[1, 1]
        cx, cy = self.K[0, 2], self.K[1, 2]

        # Get pixel coordinates where mask is True
        v_coords, u_coords = np.where(mask)
        z = depth_map[v_coords, u_coords]

        # Filter out invalid depths
        valid = z > 0.01
        v_coords, u_coords, z = v_coords[valid], u_coords[valid], z[valid]

        if len(z) == 0:
            return np.empty((0, 3), dtype=np.float32)

        # Back-project to 3D (camera frame)
        x = (u_coords - cx) * z / fx
        y = (v_coords - cy) * z / fy
        points_cam = np.stack([x, y, z], axis=-1).astype(np.float32)

        # Transform to robot base frame
        points_cam_homo = np.hstack([
            points_cam,
            np.ones((len(points_cam), 1), dtype=np.float32)
        ])
        points_base = (self.T_cam_to_base @ points_cam_homo.T).T[:, :3]

        return points_base

    # ─── Full pipeline ───────────────────────────────────────────

    def process(
        self,
        image: np.ndarray,
        text_prompt: str,
        downsample_points: int = 2000,
    ) -> ScenePerception:
        """
        Full perception pipeline: image → segmentation → depth → point clouds.

        Args:
            image: (H, W, 3) RGB uint8
            text_prompt: dot-separated object labels
            downsample_points: max points per object (for speed)

        Returns:
            ScenePerception with all detected objects and their point clouds
        """
        logger.info("Running perception pipeline...")

        # Step 1: Segment
        logger.info("  Step 1: Semantic segmentation")
        objects = self.segment(image, text_prompt)
        logger.info(f"    Detected {len(objects)} objects: "
                     f"{[o.label for o in objects]}")

        # Step 2: Depth
        logger.info("  Step 2: Depth estimation")
        depth_map = self.estimate_depth(image)
        logger.info(f"    Depth range: [{depth_map.min():.3f}, "
                     f"{depth_map.max():.3f}] m")

        # Step 3: Lift to 3D
        logger.info("  Step 3: 3D point cloud lifting")
        for obj in objects:
            pc = self.lift_to_3d(depth_map, obj.mask)

            # Downsample if too many points
            if len(pc) > downsample_points:
                indices = np.random.choice(
                    len(pc), downsample_points, replace=False
                )
                pc = pc[indices]

            obj.point_cloud = pc
            logger.info(f"    {obj.label}: {pc.shape[0]} points")

        scene = ScenePerception(
            image=image,
            depth_map=depth_map,
            objects=objects,
        )

        return scene
