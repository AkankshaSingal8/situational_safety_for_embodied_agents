#!/usr/bin/env python3
"""Visualize the superquadric constraint envelopes for the laptop scene."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

fig = plt.figure(figsize=(18, 7))

# ── Scene parameters (from the pipeline run) ──
# Laptop keyboard
np.random.seed(42)
n = 800
kb_x = np.random.uniform(-0.18, 0.18, n)
kb_y = np.random.uniform(-0.12, 0.12, n)
kb_z = np.random.uniform(0.0, 0.02, n)
kb_center = np.array([0.45, 0.0, 0.01])
pc_kb = np.stack([kb_x, kb_y, kb_z], axis=1) + kb_center

# Screen
sc_x = np.random.uniform(-0.17, 0.17, n)
sc_z_local = np.random.uniform(0.0, 0.22, n)
tilt = np.radians(20)
sc_y = -0.12 - sc_z_local * np.sin(tilt)
sc_z = 0.02 + sc_z_local * np.cos(tilt)
pc_sc = np.stack([sc_x + 0.45, sc_y, sc_z], axis=1)

# Superquadric envelope parameters (from pipeline output)
c_sq = np.array([0.4477, -0.0789, 0.4354])
a_sq = np.array([0.4552, 0.2063, 0.2188])
R_sq = np.array([[-0.0004, -0.9953, +0.0967],
                 [-0.0181, -0.0966, -0.9952],
                 [+0.9998, -0.0022, -0.0180]])

# Generate ellipsoid surface
u_angles = np.linspace(0, 2*np.pi, 40)
v_angles = np.linspace(0, np.pi, 25)
U, V = np.meshgrid(u_angles, v_angles)
ex = a_sq[0] * np.cos(U) * np.sin(V)
ey = a_sq[1] * np.sin(U) * np.sin(V)
ez = a_sq[2] * np.cos(V)

# Rotate and translate
X_ell = np.zeros_like(ex)
Y_ell = np.zeros_like(ey)
Z_ell = np.zeros_like(ez)
for i in range(ex.shape[0]):
    for j in range(ex.shape[1]):
        p = R_sq @ np.array([ex[i,j], ey[i,j], ez[i,j]]) + c_sq
        X_ell[i,j], Y_ell[i,j], Z_ell[i,j] = p

# Test positions
test_pts = {
    "above center\n(UNSAFE)": (np.array([0.45, 0.0, 0.40]), 'red'),
    "beside\n(SAFE)":         (np.array([0.45, 0.35, 0.10]), 'green'),
    "far away\n(SAFE)":       (np.array([0.0, 0.0, 0.30]), 'green'),
    "above edge\n(SAFE)":     (np.array([0.65, 0.0, 0.40]), 'green'),
}

# ══════════════════ PLOT 1: 3D Constraint Envelope ══════════════════
ax1 = fig.add_subplot(131, projection='3d')
ax1.set_title('Semantic Safety Constraint Envelope\n(laptop, above) — cup of water', 
              fontsize=11, fontweight='bold', pad=15)

# Desk surface
desk_corners = np.array([[-0.2, -0.35, 0], [0.75, -0.35, 0],
                          [0.75, 0.35, 0], [-0.2, 0.35, 0]])
desk = Poly3DCollection([desk_corners], alpha=0.15, facecolor='tan', edgecolor='brown')
ax1.add_collection3d(desk)

# Laptop point clouds
ax1.scatter(pc_kb[:, 0], pc_kb[:, 1], pc_kb[:, 2], c='silver', s=0.3, alpha=0.5, label='keyboard')
ax1.scatter(pc_sc[:, 0], pc_sc[:, 1], pc_sc[:, 2], c='darkgray', s=0.3, alpha=0.5, label='screen')

# Constraint envelope (superquadric)
ax1.plot_surface(X_ell, Y_ell, Z_ell, alpha=0.12, color='red', edgecolor='red', linewidth=0.1)

# Test points
for label, (pt, color) in test_pts.items():
    ax1.scatter(*pt, c=color, s=80, marker='o', edgecolor='black', linewidth=0.8, zorder=10)
    ax1.text(pt[0]+0.03, pt[1]+0.03, pt[2]+0.03, label, fontsize=7, color=color, fontweight='bold')

ax1.set_xlabel('X (m)', fontsize=9)
ax1.set_ylabel('Y (m)', fontsize=9)
ax1.set_zlabel('Z (m)', fontsize=9)
ax1.set_xlim(-0.1, 0.75)
ax1.set_ylim(-0.4, 0.4)
ax1.set_zlim(0, 0.8)
ax1.view_init(elev=25, azim=-55)

# ══════════════════ PLOT 2: CBF value heatmap (XZ plane) ══════════════════
ax2 = fig.add_subplot(132)
ax2.set_title('h_sem(x_ee) — CBF values in XZ plane\n(y=0, through laptop center)', 
              fontsize=11, fontweight='bold')

xs = np.linspace(-0.1, 0.8, 200)
zs = np.linspace(0.0, 0.8, 200)
XX, ZZ = np.meshgrid(xs, zs)
H_vals = np.zeros_like(XX)

for i in range(len(zs)):
    for j in range(len(xs)):
        x_ee = np.array([XX[i,j], 0.0, ZZ[i,j]])
        tau = R_sq.T @ (x_ee - c_sq)
        g = (tau[0]/a_sq[0])**2 + (tau[1]/a_sq[1])**2 + (tau[2]/a_sq[2])**2
        H_vals[i,j] = g - 1.0

# Clamp for visualization
H_vals_clamp = np.clip(H_vals, -2, 5)

contour = ax2.contourf(XX, ZZ, H_vals_clamp, levels=30, cmap='RdYlGn')
ax2.contour(XX, ZZ, H_vals, levels=[0], colors='black', linewidths=2.5)
ax2.text(0.15, 0.72, 'h=0 (boundary)', fontsize=9, fontweight='bold',
         bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

# Laptop outline
ax2.fill_between([0.27, 0.63], 0, 0.02, color='silver', alpha=0.8)
ax2.plot([0.27, 0.63, 0.63, 0.27, 0.27], [0, 0, 0.02, 0.02, 0], 'k-', linewidth=1.5)
ax2.text(0.45, 0.035, 'laptop', ha='center', fontsize=8, color='gray')

# Test points
for label, (pt, color) in test_pts.items():
    ax2.plot(pt[0], pt[2], 'o', color=color, markersize=8, markeredgecolor='black', markeredgewidth=1)
    clean_label = label.replace('\n', ' ')
    ax2.annotate(clean_label, (pt[0], pt[2]), textcoords="offset points",
                xytext=(8, 5), fontsize=7, color=color, fontweight='bold')

cb = fig.colorbar(contour, ax=ax2, shrink=0.8)
cb.set_label('h_sem (≥0: safe, <0: unsafe)', fontsize=9)
ax2.set_xlabel('X (m)', fontsize=10)
ax2.set_ylabel('Z (m)', fontsize=10)
ax2.set_aspect('equal')

# ══════════════════ PLOT 3: CBF condition analysis ══════════════════
ax3 = fig.add_subplot(133)
ax3.set_title('Class-K∞ Functions\n(Behavioral Constraint Modulation)', 
              fontsize=11, fontweight='bold')

h_range = np.linspace(0, 3, 100)
alpha_std = h_range**2
alpha_caut = 0.25 * h_range**2

ax3.plot(h_range, alpha_std, 'b-', linewidth=2.5, label=r'$\alpha_{sem}(h) = h^2$ (standard)')
ax3.plot(h_range, alpha_caut, 'r--', linewidth=2.5, label=r'$\alpha_{sem,c}(h) = \frac{1}{4}h^2$ (caution)')
ax3.fill_between(h_range, alpha_caut, alpha_std, alpha=0.1, color='orange')
ax3.annotate('Robot approaches\nboundary SLOWER\nwith caution', 
             xy=(1.8, 1.5), fontsize=9, ha='center',
             bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.9))

ax3.set_xlabel('h(x) — distance from unsafe boundary', fontsize=10)
ax3.set_ylabel(r'$\alpha(h)$ — allowed approach rate', fontsize=10)
ax3.legend(fontsize=9, loc='upper left')
ax3.grid(True, alpha=0.3)
ax3.set_xlim(0, 3)
ax3.set_ylim(0, 5)

# Add text box with constraint summary
textstr = (
    "Scene: HP laptop on desk\n"
    "Held: cup of water\n\n"
    "S_r = {(laptop, above), (laptop, over)}\n"
    "S_b = {(laptop, caution), (desk, caution)}\n"
    "S_T = {constrained_rotation}"
)
props = dict(boxstyle='round', facecolor='lightyellow', alpha=0.9)
ax3.text(0.55, 0.35, textstr, transform=ax3.transAxes, fontsize=8,
         verticalalignment='top', bbox=props, family='monospace')

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cbf_visualization.png', dpi=180, bbox_inches='tight')
print("Saved visualization to cbf_visualization.png")
