#!/usr/bin/env python3
"""
Semantic Safety Filter — End-to-End Demo

Full pipeline:
  Image → Segmentation → Depth → 3D Point Clouds → VLM Constraint Synthesis
  → Superquadric Fitting → CBF-QP Safety Filter → Certified Joint Velocity

Usage:
  python demo/run_from_image.py \
    --image path/to/scene.png \
    --held_object "cup of water" \
    --use_mock   # for testing without models/API

  python demo/run_from_image.py \
    --image path/to/scene.png \
    --held_object "cup of water" \
    --vlm_model gpt-4o \
    --spatial_rels above under around
"""

import sys
import os
import argparse
import logging
import json
import numpy as np

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from perception.pipeline import PerceptionPipeline, ScenePerception
from semantics.vlm_query import VLMConstraintSynthesizer, SemanticConstraints
from geometry.superquadric import (
    SuperquadricFitter, SuperquadricParams, build_constraint_envelopes
)
from safety_filter.cbf_qp import SemanticSafetyFilter


# ─────────────────────────────────────────────────────────────────────
# Mock robot model for testing
# ─────────────────────────────────────────────────────────────────────

class MockRobot:
    """Simple 7-DoF robot model for testing the pipeline."""

    def __init__(self, n_joints=7):
        self.n_joints = n_joints
        self.q_min = -np.pi * np.ones(n_joints)
        self.q_max = np.pi * np.ones(n_joints)

    def forward_kinematics(self, q: np.ndarray) -> np.ndarray:
        """Mock FK: returns a position based on first 3 joints."""
        x = 0.4 * np.cos(q[0]) * np.cos(q[1])
        y = 0.4 * np.sin(q[0]) * np.cos(q[1])
        z = 0.3 + 0.3 * np.sin(q[1]) + 0.1 * q[2]
        return np.array([x, y, z])

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        """Mock Jacobian (6 x n_joints)."""
        J = np.zeros((6, self.n_joints))
        # Rough approximation for translational part
        J[0, 0] = -0.4 * np.sin(q[0]) * np.cos(q[1])
        J[0, 1] = -0.4 * np.cos(q[0]) * np.sin(q[1])
        J[1, 0] = 0.4 * np.cos(q[0]) * np.cos(q[1])
        J[1, 1] = -0.4 * np.sin(q[0]) * np.sin(q[1])
        J[2, 1] = 0.3 * np.cos(q[1])
        J[2, 2] = 0.1
        # Orientation part (identity-like for testing)
        J[3:, 3:6] = np.eye(3) if self.n_joints >= 6 else np.eye(min(3, self.n_joints - 3))
        return J

    def orientation(self, q: np.ndarray) -> np.ndarray:
        """Mock end-effector orientation."""
        return np.eye(3)


# ─────────────────────────────────────────────────────────────────────
# Main pipeline
# ─────────────────────────────────────────────────────────────────────

def run_pipeline(
    image_path: str,
    held_object: str,
    text_prompt: str = "",
    vlm_model: str = "gpt-4o",
    num_votes: int = 3,
    spatial_rels: list = None,
    use_mock: bool = False,
    verbose: bool = True,
):
    """
    Run the full semantic safety filter pipeline.

    Returns:
        dict with all intermediate results
    """
    results = {}

    # ─── Load image ───
    if use_mock:
        image = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        if not text_prompt:
            text_prompt = "laptop . book . phone"
    else:
        try:
            from PIL import Image
            img = Image.open(image_path).convert("RGB")
            image = np.array(img)
        except Exception as e:
            print(f"Error loading image: {e}")
            print("Using mock image instead")
            image = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
            use_mock = True

    print(f"Image shape: {image.shape}")
    print(f"Held object: '{held_object}'")
    print(f"Object prompt: '{text_prompt}'")
    print()

    # ─── Step 1-3: Perception ───
    print("=" * 60)
    print("STEPS 1-3: PERCEPTION PIPELINE")
    print("=" * 60)

    K = np.array([
        [600, 0, image.shape[1] / 2],
        [0, 600, image.shape[0] / 2],
        [0, 0, 1],
    ])

    perception = PerceptionPipeline(
        camera_intrinsics=K,
        use_mock=use_mock,
    )
    scene = perception.process(image, text_prompt)
    results["scene"] = scene

    print(f"\nDetected objects: {scene.labels}")
    for label, pc in scene.point_clouds.items():
        print(f"  {label}: {pc.shape[0]} points, "
              f"centroid = {pc.mean(axis=0).round(4)}")
    print()

    # ─── Step 4: VLM Constraint Synthesis ───
    print("=" * 60)
    print("STEP 4: VLM SEMANTIC CONSTRAINT SYNTHESIS")
    print("=" * 60)

    synth = VLMConstraintSynthesizer(
        model=vlm_model,
        num_votes=num_votes,
        use_mock=use_mock,
    )
    constraints = synth.synthesize(
        held_object=held_object,
        scene_objects=scene.labels,
        spatial_relationships=spatial_rels,
    )
    results["constraints"] = constraints

    print(f"\n{constraints.summary()}")
    print()

    # ─── Step 5: Superquadric Fitting ───
    print("=" * 60)
    print("STEP 5: SUPERQUADRIC FITTING & CONSTRAINT ENVELOPES")
    print("=" * 60)

    workspace = {
        "x_min": -1.0, "x_max": 1.0,
        "y_min": -1.0, "y_max": 1.0,
        "z_min": 0.0,  "z_max": 1.2,
    }

    envelopes = build_constraint_envelopes(
        point_clouds=scene.point_clouds,
        spatial_constraints=constraints.S_r,
        workspace_bounds=workspace,
    )
    results["envelopes"] = envelopes

    print(f"\nBuilt {len(envelopes)} constraint envelopes:")
    for env in envelopes:
        print(f"  {env}")
    print()

    # ─── Step 6: CBF-QP Safety Filter ───
    print("=" * 60)
    print("STEP 6: CBF-QP SAFETY FILTER")
    print("=" * 60)

    robot = MockRobot(n_joints=7)

    safety_filter = SemanticSafetyFilter(
        n_joints=7,
        dt=0.022,
        u_max=1.5,
    )
    safety_filter.set_semantic_constraints(
        envelopes=envelopes,
        behavioral_constraints=constraints.S_b,
        pose_constraint=constraints.S_T,
    )

    # Test with a nominal command
    q = np.zeros(7)
    u_cmd = np.random.randn(7) * 0.5

    print(f"\nTest configuration:")
    print(f"  q = {q.round(4)}")
    print(f"  u_cmd = {u_cmd.round(4)}")

    x_ee = robot.forward_kinematics(q)
    print(f"  x_ee (FK) = {x_ee.round(4)}")

    # Evaluate CBFs at current position
    print(f"\nCBF values at current position:")
    fitter = SuperquadricFitter()
    for env in envelopes:
        h_val = fitter.evaluate_cbf(x_ee, env)
        status = "SAFE" if h_val >= 0 else "VIOLATED"
        print(f"  h({env.object_label}, {env.relationship}) = "
              f"{h_val:.4f}  [{status}]")

    # Solve QP
    u_cert = safety_filter.solve(
        q=q,
        u_cmd=u_cmd,
        jacobian_fn=robot.jacobian,
        fk_fn=robot.forward_kinematics,
        q_min=robot.q_min,
        q_max=robot.q_max,
        R_cur=robot.orientation(q),
    )
    results["u_cert"] = u_cert

    print(f"\n  u_cmd  = {u_cmd.round(4)}")
    print(f"  u_cert = {u_cert.round(4)}")
    print(f"  ‖u_cmd − u_cert‖ = {np.linalg.norm(u_cmd - u_cert):.4f}")
    print(f"  modification = {np.linalg.norm(u_cmd - u_cert) / (np.linalg.norm(u_cmd) + 1e-8) * 100:.1f}%")

    # Verify constraints after certification
    x_ee_next = robot.forward_kinematics(q + u_cert * safety_filter.dt)
    print(f"\n  Predicted next x_ee = {x_ee_next.round(4)}")
    print(f"  CBF values after certified step:")
    for env in envelopes:
        h_next = fitter.evaluate_cbf(x_ee_next, env)
        status = "SAFE" if h_next >= 0 else "VIOLATED"
        print(f"    h({env.object_label}, {env.relationship}) = "
              f"{h_next:.4f}  [{status}]")

    print("\n" + "=" * 60)
    print("PIPELINE COMPLETE")
    print("=" * 60)

    return results


# ─────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Semantic Safety Filter — End-to-End Demo"
    )
    parser.add_argument("--image", type=str, default="",
                       help="Path to RGB scene image")
    parser.add_argument("--held_object", type=str, default="cup of water",
                       help="Object the robot is holding")
    parser.add_argument("--text_prompt", type=str, default="laptop . book . phone",
                       help="Dot-separated object labels for detection")
    parser.add_argument("--vlm_model", type=str, default="gpt-4o",
                       help="VLM model name")
    parser.add_argument("--num_votes", type=int, default=3,
                       help="Number of majority votes per query")
    parser.add_argument("--spatial_rels", nargs="+",
                       default=["above", "under", "around"],
                       help="Spatial relationships to query (subset for speed)")
    parser.add_argument("--use_mock", action="store_true",
                       help="Use mock models/API for testing")
    parser.add_argument("--verbose", action="store_true",
                       help="Verbose logging")

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    results = run_pipeline(
        image_path=args.image,
        held_object=args.held_object,
        text_prompt=args.text_prompt,
        vlm_model=args.vlm_model,
        num_votes=args.num_votes,
        spatial_rels=args.spatial_rels,
        use_mock=args.use_mock,
    )


if __name__ == "__main__":
    main()
