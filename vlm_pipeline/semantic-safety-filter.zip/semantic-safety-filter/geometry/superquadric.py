"""
Superquadric Fitting & Constraint Envelope Construction

Implements Section IV-B.1 of Brunke et al.:
  - Fit superquadric implicit functions g_i(x_ee; θ_i) to object point clouds
  - Expand point clouds based on spatial relationships (above, under, around, ...)
  - Define semantic CBFs: h_sem,i(x_ee) = g_i(x_ee; θ_i) - 1   (Eq. 1)

The superquadric implicit function:
  g(x; θ) = ((τ₁/a_x)^(2/ε₂) + (τ₂/a_y)^(2/ε₂))^(ε₂/ε₁) + (τ₃/a_z)^(2/ε₁)

  where τ₁, τ₂, τ₃ transform x_ee into the superquadric's local frame.

  g(x) < 1  →  inside (UNSAFE)
  g(x) = 1  →  on boundary
  g(x) > 1  →  outside (SAFE)
"""

import numpy as np
from typing import Tuple, List, Optional, Dict
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class SuperquadricParams:
    """Parameters of a fitted superquadric."""
    centroid: np.ndarray        # (3,) center in world frame
    rotation: np.ndarray        # (3,3) rotation to local frame
    scale: np.ndarray           # (3,) [a_x, a_y, a_z] half-axis lengths
    eps: np.ndarray             # (2,) [ε₁, ε₂] shape exponents
    object_label: str = ""
    relationship: str = ""

    def __repr__(self):
        return (f"Superquadric(label='{self.object_label}', "
                f"rel='{self.relationship}', "
                f"scale={self.scale.round(4)}, "
                f"eps={self.eps.round(2)})")


class SuperquadricFitter:
    """
    Fits superquadric implicit functions to point clouds and constructs
    constraint envelopes based on semantic spatial relationships.

    Usage:
        fitter = SuperquadricFitter(safety_margin=0.03)

        # Expand point cloud for "above" relationship
        pc_expanded = fitter.expand_point_cloud(pc_laptop, "above", workspace)

        # Fit superquadric
        params = fitter.fit(pc_expanded, label="laptop", relationship="above")

        # Evaluate: is x_ee safe?
        h_val = fitter.evaluate_cbf(x_ee, params)  # h >= 0 means safe
    """

    def __init__(self, safety_margin: float = 0.03):
        self.margin = safety_margin

    # ─── Point cloud expansion by spatial relationship ───────────

    def expand_point_cloud(
        self,
        point_cloud: np.ndarray,
        relationship: str,
        workspace_bounds: Dict[str, float],
    ) -> np.ndarray:
        """
        Expand an object's point cloud to cover the unsafe region defined
        by the spatial relationship.

        From Section IV-B.1:
          "To account for the spatial relationship 'above', we extend the
           point cloud in its positive z-direction. We duplicate the point
           cloud, set the duplicate's z-coordinates to be outside the
           robot's workspace, and fit the superquadric based on the union
           of the original and the expanded point cloud."

        Args:
            point_cloud: (N, 3) object point cloud
            relationship: one of the 12 spatial relationships
            workspace_bounds: dict with keys z_min, z_max, x_min, etc.

        Returns:
            expanded_pc: (M, 3) expanded point cloud
        """
        pc = point_cloud.copy()
        pc_dup = pc.copy()

        z_max = workspace_bounds.get("z_max", 1.2)
        z_min = workspace_bounds.get("z_min", 0.0)
        x_min = workspace_bounds.get("x_min", -1.0)
        x_max = workspace_bounds.get("x_max", 1.0)
        y_min = workspace_bounds.get("y_min", -1.0)
        y_max = workspace_bounds.get("y_max", 1.0)

        if relationship == "above" or relationship == "over":
            # Extend upward: duplicate z → workspace ceiling
            pc_dup[:, 2] = z_max
            return np.vstack([pc, pc_dup])

        elif relationship == "under":
            # Extend downward: duplicate z → workspace floor
            pc_dup[:, 2] = z_min
            return np.vstack([pc, pc_dup])

        elif relationship == "around" or relationship == "near":
            # Inflate radially by safety margin + extra buffer
            centroid = pc.mean(axis=0)
            directions = pc - centroid
            norms = np.linalg.norm(directions, axis=1, keepdims=True)
            norms = np.maximum(norms, 1e-6)
            unit_dirs = directions / norms
            inflate_dist = self.margin * 5  # substantial buffer for "around"
            pc_expanded = pc + unit_dirs * inflate_dist
            return np.vstack([pc, pc_expanded])

        elif relationship == "left":
            # Extend in negative x
            pc_dup[:, 0] = x_min
            return np.vstack([pc, pc_dup])

        elif relationship == "right":
            # Extend in positive x
            pc_dup[:, 0] = x_max
            return np.vstack([pc, pc_dup])

        elif relationship == "front":
            # Extend in negative y (toward robot)
            pc_dup[:, 1] = y_min
            return np.vstack([pc, pc_dup])

        elif relationship == "behind":
            # Extend in positive y (away from robot)
            pc_dup[:, 1] = y_max
            return np.vstack([pc, pc_dup])

        elif relationship == "on_top":
            # Small zone directly above the object surface
            z_top = pc[:, 2].max()
            pc_dup[:, 2] = z_top + 0.15  # 15cm above surface
            return np.vstack([pc, pc_dup])

        elif relationship == "inside":
            # The object's own volume (no expansion needed)
            return pc

        elif relationship == "beside":
            # Expand laterally in x and y
            pc_left = pc.copy()
            pc_left[:, 0] -= self.margin * 3
            pc_right = pc.copy()
            pc_right[:, 0] += self.margin * 3
            return np.vstack([pc, pc_left, pc_right])

        else:
            logger.warning(f"Unknown relationship '{relationship}', "
                          f"returning original point cloud")
            return pc

    # ─── Superquadric fitting ────────────────────────────────────

    def fit(
        self,
        point_cloud: np.ndarray,
        label: str = "",
        relationship: str = "",
        eps1: float = 1.0,
        eps2: float = 1.0,
    ) -> SuperquadricParams:
        """
        Fit a superquadric to the (expanded) point cloud.

        Procedure:
          1. PCA to get the local coordinate frame (rotation R, centroid c)
          2. Transform points to local frame
          3. Set scale [a_x, a_y, a_z] from the extent + safety margin
          4. Optionally optimize ε₁, ε₂ (default: 1.0 = ellipsoid)

        Args:
            point_cloud: (N, 3) points to fit
            label: object label (for bookkeeping)
            relationship: spatial relationship (for bookkeeping)
            eps1, eps2: shape exponents (1.0 = ellipsoid)

        Returns:
            SuperquadricParams
        """
        if len(point_cloud) < 4:
            logger.warning(f"Too few points ({len(point_cloud)}) for fitting")
            return SuperquadricParams(
                centroid=np.zeros(3),
                rotation=np.eye(3),
                scale=np.ones(3) * 0.1,
                eps=np.array([eps1, eps2]),
                object_label=label,
                relationship=relationship,
            )

        # Step 1: Compute centroid and PCA
        centroid = point_cloud.mean(axis=0)
        centered = point_cloud - centroid

        # SVD for principal axes
        U, S, Vt = np.linalg.svd(centered, full_matrices=False)
        R = Vt.T  # columns are principal axes

        # Ensure right-handed coordinate system
        if np.linalg.det(R) < 0:
            R[:, -1] *= -1

        # Step 2: Transform to local frame
        local_coords = centered @ R

        # Step 3: Scale from extent + margin
        # Use percentile to be robust to outliers
        extent_max = np.percentile(np.abs(local_coords), 98, axis=0)
        scale = extent_max + self.margin

        # Ensure minimum scale
        scale = np.maximum(scale, 0.01)

        params = SuperquadricParams(
            centroid=centroid,
            rotation=R,
            scale=scale,
            eps=np.array([eps1, eps2]),
            object_label=label,
            relationship=relationship,
        )

        logger.info(f"Fitted {params}")
        return params

    # ─── Superquadric evaluation ─────────────────────────────────

    @staticmethod
    def evaluate_g(
        x_ee: np.ndarray,
        params: SuperquadricParams,
    ) -> float:
        """
        Evaluate the superquadric implicit function g_i(x_ee; θ_i).

        g(x) = ((τ₁/a_x)^(2/ε₂) + (τ₂/a_y)^(2/ε₂))^(ε₂/ε₁) + (τ₃/a_z)^(2/ε₁)

        where τ = R^T (x_ee - centroid) transforms to local coordinates.

        Returns:
            g_value: float.  g < 1 → inside (unsafe), g ≥ 1 → outside (safe)
        """
        # Transform to local frame
        tau = params.rotation.T @ (x_ee - params.centroid)

        a_x, a_y, a_z = params.scale
        eps1, eps2 = params.eps

        # Clamp small exponents to avoid numerical issues
        eps1 = max(eps1, 0.05)
        eps2 = max(eps2, 0.05)

        # Superquadric implicit function
        # Inner term: (|τ₁/a_x|^(2/ε₂) + |τ₂/a_y|^(2/ε₂))^(ε₂/ε₁)
        t1 = np.abs(tau[0] / a_x) ** (2.0 / eps2)
        t2 = np.abs(tau[1] / a_y) ** (2.0 / eps2)
        inner = (t1 + t2) ** (eps2 / eps1)

        # Outer term: |τ₃/a_z|^(2/ε₁)
        t3 = np.abs(tau[2] / a_z) ** (2.0 / eps1)

        g_val = inner + t3
        return float(g_val)

    @staticmethod
    def evaluate_cbf(
        x_ee: np.ndarray,
        params: SuperquadricParams,
    ) -> float:
        """
        Evaluate the semantic CBF: h_sem,i(x_ee) = g_i(x_ee; θ_i) - 1  (Eq. 1)

        Returns:
            h_value: float.  h < 0 → unsafe, h ≥ 0 → safe
        """
        g_val = SuperquadricFitter.evaluate_g(x_ee, params)
        return g_val - 1.0

    @staticmethod
    def evaluate_cbf_gradient(
        x_ee: np.ndarray,
        params: SuperquadricParams,
        eps_fd: float = 1e-5,
    ) -> np.ndarray:
        """
        Compute ∂h_sem/∂x_ee via finite differences.

        This is H_sem in the paper:
          H_sem(q) = ∂h_sem/∂x_ee |_{x_ee = f_FK(q)}

        For production use, replace with automatic differentiation (JAX/PyTorch).

        Returns:
            gradient: (3,) ∂h/∂x_ee
        """
        grad = np.zeros(3)
        for i in range(3):
            x_plus = x_ee.copy()
            x_plus[i] += eps_fd
            x_minus = x_ee.copy()
            x_minus[i] -= eps_fd
            grad[i] = (
                SuperquadricFitter.evaluate_cbf(x_plus, params)
                - SuperquadricFitter.evaluate_cbf(x_minus, params)
            ) / (2.0 * eps_fd)
        return grad


# ─────────────────────────────────────────────────────────────────────
# Build constraint envelopes from semantic constraints + point clouds
# ─────────────────────────────────────────────────────────────────────

def build_constraint_envelopes(
    point_clouds: Dict[str, np.ndarray],
    spatial_constraints: list,       # List[SpatialConstraint]
    workspace_bounds: Dict[str, float],
    safety_margin: float = 0.03,
) -> List[SuperquadricParams]:
    """
    For each (object, relationship) pair in S_r(o), expand the point cloud
    and fit a superquadric → one CBF per constraint.

    Args:
        point_clouds: {label: (N, 3) array}
        spatial_constraints: list of SpatialConstraint from VLM synthesis
        workspace_bounds: dict with z_min, z_max, etc.
        safety_margin: meters of buffer around objects

    Returns:
        List of SuperquadricParams, one per semantic constraint
    """
    fitter = SuperquadricFitter(safety_margin=safety_margin)
    envelopes = []

    for constraint in spatial_constraints:
        label = constraint.object_label
        rel = constraint.relationship

        if label not in point_clouds:
            logger.warning(f"No point cloud for object '{label}', skipping")
            continue

        pc = point_clouds[label]
        logger.info(f"Building envelope for ({label}, {rel}): "
                    f"{pc.shape[0]} points")

        # Expand point cloud based on relationship
        pc_expanded = fitter.expand_point_cloud(pc, rel, workspace_bounds)
        logger.info(f"  Expanded to {pc_expanded.shape[0]} points")

        # Fit superquadric
        params = fitter.fit(pc_expanded, label=label, relationship=rel)
        envelopes.append(params)

    logger.info(f"Built {len(envelopes)} constraint envelopes")
    return envelopes
