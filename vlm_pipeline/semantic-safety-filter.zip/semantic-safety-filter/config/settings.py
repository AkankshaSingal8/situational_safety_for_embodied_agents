"""
Configuration dataclasses for the semantic safety filter pipeline.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class CameraIntrinsics:
    """Pinhole camera intrinsics."""
    fx: float = 600.0
    fy: float = 600.0
    cx: float = 320.0
    cy: float = 240.0
    width: int = 640
    height: int = 480


@dataclass
class WorkspaceBounds:
    """Robot workspace limits in base frame (meters)."""
    x_min: float = -1.0
    x_max: float = 1.0
    y_min: float = -1.0
    y_max: float = 1.0
    z_min: float = 0.0    # table surface
    z_max: float = 1.2    # above workspace ceiling


@dataclass
class VLMConfig:
    """VLM query configuration."""
    model: str = "gpt-4o"
    api_key: Optional[str] = None          # set via env var OPENAI_API_KEY
    num_votes: int = 3                      # majority voting count
    temperature: float = 0.3                # low temp for consistency
    max_tokens: int = 150
    spatial_relationships: List[str] = field(default_factory=lambda: [
        "above", "under", "around", "near",
        "left", "right", "front", "behind",
        "on_top", "inside", "over", "beside",
    ])


@dataclass
class SuperquadricConfig:
    """Superquadric fitting parameters."""
    safety_margin: float = 0.03             # 3 cm margin around objects
    eps1_default: float = 1.0               # shape exponent (1 = ellipsoid)
    eps2_default: float = 1.0
    max_fitting_iters: int = 100


@dataclass
class CBFConfig:
    """CBF-QP safety filter parameters."""
    alpha_standard_coeff: float = 1.0       # α(h) = coeff * h²
    alpha_caution_coeff: float = 0.25       # α_c(h) = 0.25 * h²  (paper: 1/4)
    w_rot_constrained: float = 10.0         # rotation penalty weight
    w_rot_free: float = 0.0
    dt: float = 0.02                        # control timestep (1/45 Hz ≈ 0.022)
    u_max: float = 1.5                      # joint velocity limit (rad/s)


@dataclass
class PipelineConfig:
    """Top-level pipeline configuration."""
    camera: CameraIntrinsics = field(default_factory=CameraIntrinsics)
    workspace: WorkspaceBounds = field(default_factory=WorkspaceBounds)
    vlm: VLMConfig = field(default_factory=VLMConfig)
    superquadric: SuperquadricConfig = field(default_factory=SuperquadricConfig)
    cbf: CBFConfig = field(default_factory=CBFConfig)
    # camera-to-robot-base transform (4x4), identity default
    T_cam_to_base: Optional[List[List[float]]] = None
