"""
Prompt templates for VLM semantic constraint synthesis.

These follow the MULTI-PROMPT strategy from Brunke et al. (Table I),
which achieves 60% precision / 99% recall vs 29%/78% for single-prompt.

Each constraint type is queried SEPARATELY for each (held_object, scene_object) pair.
Majority voting across multiple calls determines the final constraint.

Three constraint types from the paper's supplementary material:
  Type I:   Unsafe spatial relationships  → S_r(o)
  Type II:  Behavioral constraints        → S_b(o)
  Type III: End-effector pose constraints  → S_T(o)
"""

# ─────────────────────────────────────────────────────────────────────
# The 12 spatial relationships considered in the paper (Section IV-B.1)
# ─────────────────────────────────────────────────────────────────────
SPATIAL_RELATIONSHIPS = [
    "above", "under", "around", "near",
    "left", "right", "front", "behind",
    "on_top", "inside", "over", "beside",
]

# ─────────────────────────────────────────────────────────────────────
# TYPE I: UNSAFE SPATIAL RELATIONSHIPS — S_r(o)
# ─────────────────────────────────────────────────────────────────────

SPATIAL_SYSTEM_PROMPT = (
    "You are an intelligent assistant for robot - human interaction."
)

SPATIAL_FEW_SHOT_USER = """You are an intelligent assistant being used to guide a robot's \
decisions by telling it if certain moves are safe while holding an \
object. For the workflow, I will give you an object and some \
context and you will give me a response that begins strictly with \
Yes or with No. The second sentence is your reasoning. Do not be \
too cautious, only mark a move as unsafe if it poses a high risk to \
cause very significant damage. Less major damage or small chance of \
damage should be considered safe.

Example:
A robotic manipulator is holding a dish of snacks in its end \
effector. The robotic manipulator is on a table. Your job is to \
tell me if the object called plate is safe to go above. Please \
respond with Yes. or No. as the first sentence and then a second \
sentence with your reasoning.

In this case, you should output: Yes. There is no worry of \
significant damage or harm by navigating over a plate.

Example:
A robotic manipulator is holding a hot tea in its end effector. The \
robotic manipulator is on a table. Your job is to tell me if the \
object called phone_1 is safe to go above. Please respond with Yes. \
or No. as the first sentence and then a second sentence with your \
reasoning.

In this case, you should output: No. If the cup of hot tea spills \
on a phone it may break the phone.

Done examples.

A robotic manipulator is holding a screwdriver. The robotic \
manipulator is on a table. Your job is to tell me if the object \
called alarm_clock is safe to go above. Please respond with Yes. or \
No. as the first sentence and then a second sentence with your \
reasoning."""

SPATIAL_FEW_SHOT_ASSISTANT = (
    "Yes. It is safe to bring the screwdriver over the alarm_clock "
    "because even if the screwdriver fell on the alarm or came into "
    "contact the damage would not be very significant or costly."
)

SPATIAL_QUERY_TEMPLATE = """A robotic manipulator is holding a {end_object} in its end effector. \
The robotic manipulator is navigating atop a desk. Your job is to \
tell me if the object called {scene_object} is safe for the robot \
manipulator to go {constraint_type}. Assume the {end_object} is planned \
to go around the object at a distance of 2 cm and that the robot \
moves slowly, it may contact but if so will be soft and will stop \
immediately. Please respond with Yes. or No. as the first sentence \
and then a second sentence with your reasoning."""


# ─────────────────────────────────────────────────────────────────────
# TYPE II: BEHAVIORAL CONSTRAINTS — S_b(o)
# ─────────────────────────────────────────────────────────────────────

BEHAVIORAL_SYSTEM_PROMPT = (
    "You are an intelligent assistant for robot - human interaction."
)

BEHAVIORAL_FEW_SHOT_USER = """You are an intelligent assistant being used to guide a robot's \
decisions by telling it if extra caution should be observed while \
moving an object that it is holding. Extra caution should only be \
observed for objects that be risky to accelerate and move quickly. \
For the workflow, I will give you an object and some context and \
you will give me a response that begins strictly with Yes. or No. \
The second sentence is your reasoning.

Example:
A robotic manipulator is holding a paint_can in its end effector. \
Your job is to tell me if the object called paint_can is safe to \
move quickly or accelerate quickly towards the object called table. \
Please respond with Yes. or No. as the first sentence and then a \
second sentence with your reasoning.

In this case you should output: No. The paint can might not be \
closed and sealed, so paint may spill out and make a mess on the \
table if quickly accelerated.

Example:
A robotic manipulator is holding a tv_remote in its end effector. \
Your job is to tell me if the object called tv_remote is safe to \
move quickly or accelerate quickly towards the object called sofa. \
Please respond with Yes. or No. as the first sentence and then a \
second sentence with your reasoning.

In this case you should output: Yes. There is no danger in moving \
the tv remote quickly close to the sofa.

Done examples.

A robotic manipulator is holding a screwdriver in its end effector. \
Your job is to tell me if the object called screwdriver is safe to \
move quickly or accelerate quickly towards the object called \
toolbox. Please respond with Yes. or No. as the first sentence and \
then a second sentence with your reasoning."""

BEHAVIORAL_FEW_SHOT_ASSISTANT = (
    "Yes. A screwdriver is typically stable and can be moved quickly "
    "without risk, especially towards a toolbox, which is its expected "
    "destination."
)

BEHAVIORAL_QUERY_TEMPLATE = """A robotic manipulator is holding a {end_object} in its end effector. \
Your job is to tell me if the object called {end_object} is safe to \
move quickly or accelerate quickly towards the object called {scene_object}. \
Please respond with Yes. or No. as the first sentence and then a \
second sentence with your reasoning."""


# ─────────────────────────────────────────────────────────────────────
# TYPE III: END-EFFECTOR POSE CONSTRAINTS — S_T(o)
# ─────────────────────────────────────────────────────────────────────

POSE_SYSTEM_PROMPT = (
    "You are an intelligent assistant for robot - human interaction."
)

POSE_FEW_SHOT_USER = """You are an intelligent assistant being used to guide a robot's \
decisions by telling it if it is safe to rotate an object that it \
is holding. Assume that the rotation is collision - free, but do not \
assume that there is nothing in or on the object. For the workflow, \
I will give you an object and some context and you will give me a \
response that begins strictly with Yes. or No. The second sentence \
is your reasoning.

Example:
A robotic manipulator is holding a paint_can in its end effector. \
Your job is to tell me if the object called paint_can is safe to \
rotate. Please respond with Yes. or No. as the first sentence and \
then a second sentence with your reasoning.

In this case you should output: No. The paint can might not be \
closed and sealed, so paint may spill out and make a mess if \
rotated.

Done examples.

A robotic manipulator is holding a screwdriver in its end effector. \
Your job is to tell me if the object called screwdriver is safe to \
rotate. Please respond with Yes or No. as the first sentence and \
then a second sentence with your reasoning."""

POSE_FEW_SHOT_ASSISTANT = (
    "Yes. Rotating the screwdriver does not pose a danger to the "
    "screwdriver or its surroundings and screwdrivers do not contain "
    "anything that may spill or fall if rotated."
)

POSE_QUERY_TEMPLATE = """A robotic manipulator is holding a {end_object} in its end effector. \
Your job is to tell me if the object called {end_object} is safe to \
rotate, assuming that the rotation is collision - free. Please \
respond with Yes. or No. as the first sentence and then a second \
sentence with your reasoning."""
