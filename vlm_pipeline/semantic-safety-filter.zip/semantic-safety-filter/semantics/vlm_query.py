"""
VLM Semantic Constraint Synthesis — Multi-Prompt Strategy

Implements the prompting approach from Brunke et al. (Section IV-B, Table I).
Multi-prompt achieves 60% precision / 99% recall vs single-prompt at 29%/78%.

Each (held_object, scene_object, constraint_type) triple is queried separately.
Majority voting across `num_votes` calls determines the final answer.

Output:
  S_r(o) = [(object_label, relationship), ...]   — unsafe spatial relationships
  S_b(o) = [(object_label, "caution"/"no_caution"), ...]
  S_T(o) = "constrained_rotation" or "free_rotation"
"""

import os
import re
import logging
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass, field
from collections import Counter

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# Data structures for semantic constraints (Section IV-B)
# ─────────────────────────────────────────────────────────────────────

@dataclass
class SpatialConstraint:
    """One entry in S_r(o): (object_label, unsafe_relationship)."""
    object_label: str
    relationship: str       # e.g., "above", "under", "around"
    reasoning: str = ""     # VLM's explanation


@dataclass
class BehavioralConstraint:
    """One entry in S_b(o): (object_label, caution_level)."""
    object_label: str
    caution: str            # "caution" or "no_caution"
    reasoning: str = ""


@dataclass
class PoseConstraint:
    """S_T(o): end-effector orientation constraint."""
    constraint_type: str    # "constrained_rotation" or "free_rotation"
    reasoning: str = ""


@dataclass
class SemanticConstraints:
    """
    Full semantic context S(o) = S_r(o) ∪ S_b(o) ∪ S_T(o)
    for a given held object o in a given scene.
    """
    held_object: str
    scene_objects: List[str]
    S_r: List[SpatialConstraint] = field(default_factory=list)
    S_b: List[BehavioralConstraint] = field(default_factory=list)
    S_T: Optional[PoseConstraint] = None

    def summary(self) -> str:
        lines = [f"Semantic constraints for held object: '{self.held_object}'"]
        lines.append(f"Scene objects: {self.scene_objects}")
        lines.append("")
        lines.append("S_r (unsafe spatial relationships):")
        if self.S_r:
            for c in self.S_r:
                lines.append(f"  - ({c.object_label}, {c.relationship}): {c.reasoning}")
        else:
            lines.append("  (none)")
        lines.append("")
        lines.append("S_b (behavioral constraints):")
        if self.S_b:
            for c in self.S_b:
                lines.append(f"  - ({c.object_label}, {c.caution}): {c.reasoning}")
        else:
            lines.append("  (none)")
        lines.append("")
        lines.append(f"S_T (pose): {self.S_T.constraint_type if self.S_T else 'N/A'}")
        if self.S_T:
            lines.append(f"  Reasoning: {self.S_T.reasoning}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────
# VLM query engine
# ─────────────────────────────────────────────────────────────────────

class VLMConstraintSynthesizer:
    """
    Queries a VLM (GPT-4o or compatible) using the paper's multi-prompt
    strategy to synthesize semantic constraints.

    Usage:
        synth = VLMConstraintSynthesizer(model="gpt-4o", num_votes=3)
        constraints = synth.synthesize(
            held_object="cup of water",
            scene_objects=["laptop", "book", "phone"],
            scene_description="A desk with electronics and books"
        )
        print(constraints.summary())
    """

    # 12 spatial relationships from the paper (Section IV-B.1)
    SPATIAL_RELATIONSHIPS = [
        "above", "under", "around", "near",
        "left", "right", "front", "behind",
        "on_top", "inside", "over", "beside",
    ]

    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: Optional[str] = None,
        num_votes: int = 3,
        temperature: float = 0.3,
        max_tokens: int = 150,
        spatial_relationships: Optional[List[str]] = None,
        use_mock: bool = False,
    ):
        self.model = model
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.num_votes = num_votes
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.spatial_rels = spatial_relationships or self.SPATIAL_RELATIONSHIPS
        self.use_mock = use_mock

        if not use_mock:
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=self.api_key)
            except ImportError:
                logger.warning("openai package not installed. Using mock mode.")
                self.use_mock = True

    # ─── Core API call ───────────────────────────────────────────

    def _call_vlm(self, system_prompt: str, messages: List[Dict]) -> str:
        """
        Send a multi-turn prompt to the VLM and return the response text.

        messages is a list of {"role": ..., "content": ...} dicts representing
        the few-shot examples + final query, structured as:
          [user_few_shot, assistant_few_shot, user_query]
        """
        if self.use_mock:
            return self._mock_response(messages)

        full_messages = [{"role": "system", "content": system_prompt}] + messages

        response = self.client.chat.completions.create(
            model=self.model,
            messages=full_messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        return response.choices[0].message.content.strip()

    def _mock_response(self, messages: List[Dict]) -> str:
        """Deterministic mock for testing without API access."""
        query = messages[-1]["content"].lower()
        if "cup of water" in query or "hot tea" in query:
            if "above" in query or "over" in query:
                if any(w in query for w in ["laptop", "phone", "keyboard", "monitor"]):
                    return "No. Water may spill and damage the electronics."
            if "rotate" in query:
                return "No. Rotating a cup of water may cause spillage."
            if "quickly" in query or "accelerate" in query:
                return "No. Moving a cup of water quickly risks spilling."
        if "knife" in query or "candle" in query:
            if "rotate" in query:
                return "No. Rotating could be dangerous."
            if "quickly" in query:
                return "No. Moving quickly with a sharp/hot object is risky."
        return "Yes. This action poses no significant risk."

    # ─── Response parsing ────────────────────────────────────────

    @staticmethod
    def _parse_yes_no(response: str) -> Tuple[bool, str]:
        """
        Parse VLM response into (is_safe: bool, reasoning: str).
        The paper requires responses to start with "Yes." or "No."
        """
        response = response.strip()
        # Extract first word
        first_word = response.split(".")[0].strip().lower()

        if first_word.startswith("no"):
            is_safe = False
        elif first_word.startswith("yes"):
            is_safe = True
        else:
            # Fallback: search for yes/no anywhere in first sentence
            logger.warning(f"Ambiguous VLM response: '{response[:80]}...'")
            is_safe = "yes" not in response[:20].lower()

        # Extract reasoning (everything after the first sentence)
        sentences = re.split(r'(?<=[.!?])\s+', response, maxsplit=1)
        reasoning = sentences[1] if len(sentences) > 1 else ""

        return is_safe, reasoning

    def _majority_vote(self, query_fn, **kwargs) -> Tuple[bool, str]:
        """
        Call query_fn num_votes times and return the majority answer.
        Returns (is_safe, reasoning_from_majority).
        """
        results = []
        for _ in range(self.num_votes):
            response = query_fn(**kwargs)
            is_safe, reasoning = self._parse_yes_no(response)
            results.append((is_safe, reasoning))

        # Count votes
        safe_votes = sum(1 for r in results if r[0])
        unsafe_votes = len(results) - safe_votes
        majority_safe = safe_votes > unsafe_votes

        # Pick reasoning from the majority
        majority_reasoning = next(
            r[1] for r in results if r[0] == majority_safe
        )

        logger.info(
            f"  Majority vote: safe={safe_votes}, unsafe={unsafe_votes} "
            f"→ {'SAFE' if majority_safe else 'UNSAFE'}"
        )
        return majority_safe, majority_reasoning

    # ─── Type I: Spatial relationship queries ────────────────────

    def _query_spatial(
        self,
        end_object: str,
        scene_object: str,
        constraint_type: str,
    ) -> str:
        """Single query for one (object, relationship) pair."""
        from config.prompts import (
            SPATIAL_SYSTEM_PROMPT,
            SPATIAL_FEW_SHOT_USER,
            SPATIAL_FEW_SHOT_ASSISTANT,
            SPATIAL_QUERY_TEMPLATE,
        )

        query = SPATIAL_QUERY_TEMPLATE.format(
            end_object=end_object,
            scene_object=scene_object,
            constraint_type=constraint_type,
        )

        messages = [
            {"role": "user", "content": SPATIAL_FEW_SHOT_USER},
            {"role": "assistant", "content": SPATIAL_FEW_SHOT_ASSISTANT},
            {"role": "user", "content": query},
        ]

        return self._call_vlm(SPATIAL_SYSTEM_PROMPT, messages)

    def query_spatial_constraints(
        self,
        end_object: str,
        scene_objects: List[str],
    ) -> List[SpatialConstraint]:
        """
        Query all (scene_object, relationship) pairs to build S_r(o).

        For each object × relationship, majority-vote whether it's unsafe.
        Only UNSAFE pairs are added to S_r.
        """
        S_r = []

        for obj in scene_objects:
            for rel in self.spatial_rels:
                logger.info(f"Querying spatial: ({end_object}, {obj}, {rel})")

                is_safe, reasoning = self._majority_vote(
                    self._query_spatial,
                    end_object=end_object,
                    scene_object=obj,
                    constraint_type=rel,
                )

                if not is_safe:
                    S_r.append(SpatialConstraint(
                        object_label=obj,
                        relationship=rel,
                        reasoning=reasoning,
                    ))
                    logger.info(f"  → UNSAFE: ({obj}, {rel})")

        return S_r

    # ─── Type II: Behavioral queries ─────────────────────────────

    def _query_behavioral(
        self,
        end_object: str,
        scene_object: str,
    ) -> str:
        """Single query for behavioral caution toward one scene object."""
        from config.prompts import (
            BEHAVIORAL_SYSTEM_PROMPT,
            BEHAVIORAL_FEW_SHOT_USER,
            BEHAVIORAL_FEW_SHOT_ASSISTANT,
            BEHAVIORAL_QUERY_TEMPLATE,
        )

        query = BEHAVIORAL_QUERY_TEMPLATE.format(
            end_object=end_object,
            scene_object=scene_object,
        )

        messages = [
            {"role": "user", "content": BEHAVIORAL_FEW_SHOT_USER},
            {"role": "assistant", "content": BEHAVIORAL_FEW_SHOT_ASSISTANT},
            {"role": "user", "content": query},
        ]

        return self._call_vlm(BEHAVIORAL_SYSTEM_PROMPT, messages)

    def query_behavioral_constraints(
        self,
        end_object: str,
        scene_objects: List[str],
    ) -> List[BehavioralConstraint]:
        """
        Query each scene object to determine if caution is needed → S_b(o).

        VLM answers "Yes" (safe to move quickly) → no_caution
        VLM answers "No" (not safe to move quickly) → caution
        """
        S_b = []

        for obj in scene_objects:
            logger.info(f"Querying behavioral: ({end_object}, {obj})")

            is_safe, reasoning = self._majority_vote(
                self._query_behavioral,
                end_object=end_object,
                scene_object=obj,
            )

            caution = "no_caution" if is_safe else "caution"
            S_b.append(BehavioralConstraint(
                object_label=obj,
                caution=caution,
                reasoning=reasoning,
            ))
            logger.info(f"  → {caution}")

        return S_b

    # ─── Type III: Pose queries ──────────────────────────────────

    def _query_pose(self, end_object: str) -> str:
        """Single query for rotation safety of the held object."""
        from config.prompts import (
            POSE_SYSTEM_PROMPT,
            POSE_FEW_SHOT_USER,
            POSE_FEW_SHOT_ASSISTANT,
            POSE_QUERY_TEMPLATE,
        )

        query = POSE_QUERY_TEMPLATE.format(end_object=end_object)

        messages = [
            {"role": "user", "content": POSE_FEW_SHOT_USER},
            {"role": "assistant", "content": POSE_FEW_SHOT_ASSISTANT},
            {"role": "user", "content": query},
        ]

        return self._call_vlm(POSE_SYSTEM_PROMPT, messages)

    def query_pose_constraint(self, end_object: str) -> PoseConstraint:
        """
        Query whether the held object's rotation should be constrained → S_T(o).

        VLM answers "Yes" (safe to rotate) → free_rotation
        VLM answers "No" (not safe to rotate) → constrained_rotation
        """
        logger.info(f"Querying pose: ({end_object})")

        is_safe, reasoning = self._majority_vote(
            self._query_pose,
            end_object=end_object,
        )

        constraint_type = "free_rotation" if is_safe else "constrained_rotation"
        logger.info(f"  → {constraint_type}")

        return PoseConstraint(
            constraint_type=constraint_type,
            reasoning=reasoning,
        )

    # ─── Full synthesis ──────────────────────────────────────────

    def synthesize(
        self,
        held_object: str,
        scene_objects: List[str],
        scene_description: str = "",
        skip_spatial: bool = False,
        spatial_relationships: Optional[List[str]] = None,
    ) -> SemanticConstraints:
        """
        Full multi-prompt synthesis of all semantic constraints S(o).

        Args:
            held_object: The object the robot is holding (e.g., "cup of water")
            scene_objects: List of detected object labels in the scene
            scene_description: Optional high-level scene description
            skip_spatial: If True, skip spatial queries (for quick testing)
            spatial_relationships: Override which relationships to query
                                  (default: all 12 from the paper)

        Returns:
            SemanticConstraints with S_r, S_b, S_T populated
        """
        if spatial_relationships:
            original_rels = self.spatial_rels
            self.spatial_rels = spatial_relationships

        logger.info("=" * 60)
        logger.info(f"Synthesizing constraints for: '{held_object}'")
        logger.info(f"Scene objects: {scene_objects}")
        logger.info("=" * 60)

        constraints = SemanticConstraints(
            held_object=held_object,
            scene_objects=scene_objects,
        )

        # Type I: Spatial relationships
        if not skip_spatial:
            logger.info("\n--- Type I: Spatial Relationship Constraints ---")
            constraints.S_r = self.query_spatial_constraints(
                held_object, scene_objects
            )
        else:
            logger.info("Skipping spatial constraints (skip_spatial=True)")

        # Type II: Behavioral
        logger.info("\n--- Type II: Behavioral Constraints ---")
        constraints.S_b = self.query_behavioral_constraints(
            held_object, scene_objects
        )

        # Type III: Pose
        logger.info("\n--- Type III: Pose Constraints ---")
        constraints.S_T = self.query_pose_constraint(held_object)

        if spatial_relationships:
            self.spatial_rels = original_rels

        logger.info("\n" + "=" * 60)
        logger.info("SYNTHESIS COMPLETE")
        logger.info("=" * 60)
        logger.info(constraints.summary())

        return constraints


# ─────────────────────────────────────────────────────────────────────
# Convenience function
# ─────────────────────────────────────────────────────────────────────

def synthesize_constraints(
    held_object: str,
    scene_objects: List[str],
    model: str = "gpt-4o",
    num_votes: int = 3,
    use_mock: bool = False,
    spatial_relationships: Optional[List[str]] = None,
) -> SemanticConstraints:
    """
    One-shot convenience function for constraint synthesis.

    Example:
        constraints = synthesize_constraints(
            held_object="cup of water",
            scene_objects=["laptop", "book"],
            use_mock=True,  # for testing without API
            spatial_relationships=["above", "under", "around"],  # subset for speed
        )
    """
    synth = VLMConstraintSynthesizer(
        model=model,
        num_votes=num_votes,
        use_mock=use_mock,
    )
    return synth.synthesize(
        held_object=held_object,
        scene_objects=scene_objects,
        spatial_relationships=spatial_relationships,
    )
