"""
CBF-QP Semantic Safety Filter — Eq. 3 from Brunke et al.

Solves:
  u_cert = argmin_{u ∈ U} ‖u − u_cmd‖² + w_rot^T L_rot(q, u)

  subject to:
    ḣ_sem(q, u; S_r)  ≥ −α_sem(h_sem(q); S_b)    [semantic spatial]
    ḣ_env(q, u)        ≥ −α_env(h_env(q); S_b)    [environment collision]
    ḣ_self(q, u)       ≥ −α_self(h_self(q))        [self collision]
    ḣ_lim(q, u)        ≥ −α_lim(h_lim(q))          [joint limits]

All constraints are LINEAR in u, making this a Quadratic Program.

Key insight from the paper:
  ḣ_sem,i(q, u) = H_sem,i(q) · J(q) · u

  where H_sem,i = ∂h_sem,i/∂x_ee  and  J(q) is the robot Jacobian.

  So each CBF constraint is:  (H · J) · u ≥ −α(h)
  which is a linear constraint on u.
"""

import numpy as np
from typing import List, Tuple, Optional, Callable, Dict
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# Class-K∞ functions (Section IV-B.2)
# ─────────────────────────────────────────────────────────────────────

def alpha_standard(h: float, coeff: float = 1.0) -> float:
    """Standard class-K∞: α(h) = coeff · h²"""
    return coeff * h ** 2


def alpha_caution(h: float, coeff: float = 0.25) -> float:
    """
    Cautious class-K∞: α_c(h) = 0.25 · h²

    From the paper: "α_sem,c(h) = (1/4)h² is strictly smaller than
    α_sem(h) = h² on h > 0, the end effector approaches the boundary
    of this semantic constraint slower."
    """
    return coeff * h ** 2


# ─────────────────────────────────────────────────────────────────────
# CBF constraint data structure
# ─────────────────────────────────────────────────────────────────────

@dataclass
class CBFConstraint:
    """
    One CBF constraint for the QP.

    Represents:  (H · J) · u ≥ −α(h)
    i.e.:         A_row · u ≥ b_val
    """
    name: str                       # e.g., "sem_laptop_above"
    A_row: np.ndarray               # (n_joints,) = H @ J
    b_val: float                    # = −α(h)
    h_val: float                    # current CBF value
    constraint_type: str = "sem"    # "sem", "env", "self", "lim"


# ─────────────────────────────────────────────────────────────────────
# Safety Filter
# ─────────────────────────────────────────────────────────────────────

class SemanticSafetyFilter:
    """
    Implements the CBF-QP safety filter from Eq. 3.

    Usage:
        filter = SemanticSafetyFilter(
            n_joints=7,
            dt=0.022,
            u_max=1.5,
        )

        # Add semantic constraints from superquadric envelopes
        filter.set_semantic_constraints(envelopes, behavioral_constraints)

        # At each control timestep:
        u_cert = filter.solve(
            q=current_joint_positions,
            u_cmd=nominal_joint_velocities,
            jacobian_fn=robot.jacobian,
            fk_fn=robot.forward_kinematics,
        )
    """

    def __init__(
        self,
        n_joints: int = 7,
        dt: float = 0.022,
        u_max: float = 1.5,
        alpha_coeff: float = 1.0,
        alpha_caution_coeff: float = 0.25,
        w_rot_constrained: float = 10.0,
    ):
        self.n_joints = n_joints
        self.dt = dt
        self.u_max = u_max
        self.alpha_coeff = alpha_coeff
        self.alpha_caution_coeff = alpha_caution_coeff
        self.w_rot_constrained = w_rot_constrained

        # Constraint envelopes and behavioral flags
        self.envelopes = []           # List[SuperquadricParams]
        self.caution_map = {}         # {object_label: "caution"/"no_caution"}
        self.pose_constraint = None   # "constrained_rotation" or "free_rotation"
        self.R_des = np.eye(3)        # desired orientation (set at pickup)

    def set_semantic_constraints(
        self,
        envelopes,                    # List[SuperquadricParams]
        behavioral_constraints,       # List[BehavioralConstraint]
        pose_constraint=None,         # PoseConstraint
        R_des: np.ndarray = None,     # desired rotation at pickup
    ):
        """Set the semantic constraints from VLM synthesis output."""
        self.envelopes = envelopes

        # Build caution lookup
        self.caution_map = {}
        for bc in behavioral_constraints:
            self.caution_map[bc.object_label] = bc.caution

        # Pose constraint
        if pose_constraint:
            self.pose_constraint = pose_constraint.constraint_type
        if R_des is not None:
            self.R_des = R_des

    def _get_alpha_fn(self, object_label: str) -> Callable:
        """
        Select the class-K∞ function based on behavioral constraint.
        caution → slower approach (smaller α)
        no_caution → standard approach
        """
        caution = self.caution_map.get(object_label, "no_caution")
        if caution == "caution":
            return lambda h: alpha_caution(h, self.alpha_caution_coeff)
        else:
            return lambda h: alpha_standard(h, self.alpha_coeff)

    def _build_semantic_constraints(
        self,
        q: np.ndarray,
        x_ee: np.ndarray,
        J: np.ndarray,
    ) -> List[CBFConstraint]:
        """
        Build CBF constraints for all semantic spatial relationships.

        For each envelope i:
          ḣ_sem,i = H_sem,i · J · u ≥ −α_sem(h_sem,i; S_b)

        where H_sem,i = ∂h_sem,i/∂x_ee (gradient of the superquadric CBF).
        """
        from geometry.superquadric import SuperquadricFitter

        constraints = []

        for env in self.envelopes:
            # Evaluate CBF value
            h_val = SuperquadricFitter.evaluate_cbf(x_ee, env)

            # Evaluate gradient ∂h/∂x_ee
            H = SuperquadricFitter.evaluate_cbf_gradient(x_ee, env)

            # A_row = H @ J  (chain rule: ∂h/∂q = ∂h/∂x_ee · ∂x_ee/∂q)
            A_row = H @ J[:3, :]   # J[:3,:] is translational Jacobian

            # Select α based on behavioral constraint for this object
            alpha_fn = self._get_alpha_fn(env.object_label)
            alpha_h = alpha_fn(max(h_val, 0))  # α only needs h > 0 regime

            constraints.append(CBFConstraint(
                name=f"sem_{env.object_label}_{env.relationship}",
                A_row=A_row,
                b_val=-alpha_h,
                h_val=h_val,
                constraint_type="sem",
            ))

        return constraints

    def _build_joint_limit_constraints(
        self,
        q: np.ndarray,
        q_min: np.ndarray,
        q_max: np.ndarray,
    ) -> List[CBFConstraint]:
        """
        Joint angle limits as CBFs:
          h_lim,upper = q_max - q  → ḣ = -u ≥ −α(h)  →  u ≤ α(h)
          h_lim,lower = q - q_min  → ḣ =  u ≥ −α(h)  → −u ≤ α(h)
        """
        constraints = []

        for i in range(self.n_joints):
            # Upper limit: h = q_max_i - q_i
            h_upper = q_max[i] - q[i]
            A_upper = np.zeros(self.n_joints)
            A_upper[i] = -1.0  # ḣ = -u_i
            alpha_h = alpha_standard(max(h_upper, 0), 1.0)
            constraints.append(CBFConstraint(
                name=f"lim_upper_{i}",
                A_row=A_upper,
                b_val=-alpha_h,
                h_val=h_upper,
                constraint_type="lim",
            ))

            # Lower limit: h = q_i - q_min_i
            h_lower = q[i] - q_min[i]
            A_lower = np.zeros(self.n_joints)
            A_lower[i] = 1.0   # ḣ = u_i
            alpha_h = alpha_standard(max(h_lower, 0), 1.0)
            constraints.append(CBFConstraint(
                name=f"lim_lower_{i}",
                A_row=A_lower,
                b_val=-alpha_h,
                h_val=h_lower,
                constraint_type="lim",
            ))

        return constraints

    def _build_rotation_cost(
        self,
        R_cur: np.ndarray,
        J_o: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Build the rotation penalty matrices for the QP objective.

        From Section IV-B.3:
          L_rot = [‖log(R_des R_cur^T)^∨ − ψ‖², ‖ψ‖²]^T
          where ψ = J_o(q) · u · Δt

        This adds a quadratic penalty on u via:
          w_rot^T L_rot ≈ u^T P_rot u + q_rot^T u

        Returns:
            P_rot: (n, n) additional quadratic term
            q_rot: (n,) additional linear term
        """
        if self.pose_constraint != "constrained_rotation":
            return np.zeros((self.n_joints, self.n_joints)), \
                   np.zeros(self.n_joints)

        # Rotation error: log(R_des @ R_cur^T)^∨
        R_err = self.R_des @ R_cur.T
        # Rodrigues log map (simplified for small rotations)
        angle = np.arccos(np.clip((np.trace(R_err) - 1) / 2, -1, 1))
        if angle < 1e-6:
            rot_err = np.zeros(3)
        else:
            skew = (R_err - R_err.T) / (2 * np.sin(angle))
            rot_err = angle * np.array([skew[2, 1], skew[0, 2], skew[1, 0]])

        # ψ = J_o · u · Δt
        # L_rot ≈ ‖rot_err - J_o·u·Δt‖² + ‖J_o·u·Δt‖²
        #       = u^T (2·Δt²·J_o^T·J_o) u - 2·Δt·rot_err^T·J_o·u + const

        J_o_3 = J_o[3:, :] if J_o.shape[0] >= 6 else J_o[:3, :]  # orientation part
        w = self.w_rot_constrained

        P_rot = 2 * w * self.dt**2 * (J_o_3.T @ J_o_3)
        q_rot = -2 * w * self.dt * (J_o_3.T @ rot_err)

        return P_rot, q_rot

    def solve(
        self,
        q: np.ndarray,
        u_cmd: np.ndarray,
        jacobian_fn: Callable,
        fk_fn: Callable,
        q_min: Optional[np.ndarray] = None,
        q_max: Optional[np.ndarray] = None,
        R_cur: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        Solve the CBF-QP (Eq. 3) to get the certified joint velocity.

        Args:
            q: (n,) current joint positions
            u_cmd: (n,) nominal joint velocity command
            jacobian_fn: callable(q) → (6, n) full Jacobian
            fk_fn: callable(q) → (3,) end-effector position
            q_min, q_max: (n,) joint limits
            R_cur: (3, 3) current end-effector orientation

        Returns:
            u_cert: (n,) certified joint velocity
        """
        n = self.n_joints
        x_ee = fk_fn(q)
        J = jacobian_fn(q)   # (6, n) or (3, n)

        # ─── Collect all CBF constraints ───
        all_constraints = []

        # 1. Semantic spatial constraints
        sem_constraints = self._build_semantic_constraints(q, x_ee, J)
        all_constraints.extend(sem_constraints)

        # 2. Joint limit constraints
        if q_min is not None and q_max is not None:
            lim_constraints = self._build_joint_limit_constraints(q, q_min, q_max)
            all_constraints.extend(lim_constraints)

        # ─── Build QP ───
        # Objective: min 0.5 u^T P u + c^T u
        P = np.eye(n)
        c = -u_cmd.copy()

        # Add rotation penalty if constrained
        if R_cur is not None:
            P_rot, q_rot = self._build_rotation_cost(R_cur, J)
            P = P + P_rot
            c = c + q_rot

        # Constraints: A u >= b  (each row is one CBF constraint)
        if all_constraints:
            A = np.vstack([con.A_row for con in all_constraints])
            b = np.array([con.b_val for con in all_constraints])
        else:
            A = np.zeros((0, n))
            b = np.array([])

        # Velocity limits: -u_max <= u <= u_max
        # Add as additional constraints
        A_vel = np.vstack([np.eye(n), -np.eye(n)])
        b_vel = np.concatenate([
            -self.u_max * np.ones(n),  # u >= -u_max → u ≥ -u_max
            -self.u_max * np.ones(n),  # -u >= -u_max → u ≤ u_max
        ])

        if len(b) > 0:
            A_full = np.vstack([A, A_vel])
            b_full = np.concatenate([b, b_vel])
        else:
            A_full = A_vel
            b_full = b_vel

        # ─── Solve QP ───
        u_cert = self._solve_qp(P, c, A_full, b_full)

        # Log constraint status
        if logger.isEnabledFor(logging.DEBUG):
            for con in sem_constraints:
                status = "SAFE" if con.h_val >= 0 else "VIOLATED"
                logger.debug(f"  {con.name}: h={con.h_val:.4f} [{status}]")

        return u_cert

    def _solve_qp(
        self,
        P: np.ndarray,
        c: np.ndarray,
        A: np.ndarray,
        b: np.ndarray,
    ) -> np.ndarray:
        """
        Solve the QP:
          min  0.5 u^T P u + c^T u
          s.t. A u >= b

        Uses OSQP if available, otherwise falls back to a simple
        projected gradient method.
        """
        n = P.shape[0]

        try:
            import osqp
            from scipy import sparse

            # OSQP standard form: min 0.5 x^T P x + q^T x  s.t.  l <= Ax <= u
            P_sparse = sparse.csc_matrix(P)

            # CBF constraints: A_cbf @ u >= b_cbf  →  b_cbf <= A_cbf @ u <= +inf
            A_sparse = sparse.csc_matrix(A)
            l_bounds = b
            u_bounds = np.full(len(b), np.inf)

            solver = osqp.OSQP()
            solver.setup(
                P_sparse, c, A_sparse, l_bounds, u_bounds,
                verbose=False,
                eps_abs=1e-6,
                eps_rel=1e-6,
                max_iter=1000,
                warm_start=True,
            )
            result = solver.solve()

            if result.info.status == "solved":
                return result.x
            else:
                logger.warning(f"QP status: {result.info.status}, "
                              "returning u_cmd clipped")
                return np.clip(result.x if result.x is not None
                              else np.zeros(n),
                              -self.u_max, self.u_max)

        except ImportError:
            logger.warning("OSQP not installed, using cvxpy fallback")
            return self._solve_qp_cvxpy(P, c, A, b)

    def _solve_qp_cvxpy(
        self,
        P: np.ndarray,
        c: np.ndarray,
        A: np.ndarray,
        b: np.ndarray,
    ) -> np.ndarray:
        """Fallback QP solver using cvxpy."""
        try:
            import cvxpy as cp

            n = P.shape[0]
            u = cp.Variable(n)

            objective = cp.Minimize(0.5 * cp.quad_form(u, P) + c @ u)
            constraints = [A @ u >= b]

            prob = cp.Problem(objective, constraints)
            prob.solve(solver=cp.OSQP, verbose=False)

            if prob.status == "optimal":
                return u.value
            else:
                logger.warning(f"cvxpy status: {prob.status}")
                return np.zeros(n)

        except ImportError:
            logger.error("Neither OSQP nor cvxpy installed!")
            logger.error("Install with: pip install osqp cvxpy")
            return np.zeros(P.shape[0])
