#!/usr/bin/env python3
"""
Test: VLM multi-prompt constraint synthesis with mock responses.

Validates the three constraint types from the paper's supplementary:
  Type I:   Spatial relationships  → S_r(o)
  Type II:  Behavioral             → S_b(o)
  Type III: Pose                   → S_T(o)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from semantics.vlm_query import VLMConstraintSynthesizer

def test_cup_of_water():
    """
    Test case from the paper: cup of water in a scene with a laptop.

    Expected output (Section IV-B):
      S_r(o) = {(laptop, above)}
      S_b(o) = {(laptop, caution)}
      S_T(o) = {constrained_rotation}
    """
    print("=" * 60)
    print("TEST: Cup of water → laptop scene")
    print("=" * 60)

    synth = VLMConstraintSynthesizer(use_mock=True, num_votes=3)

    constraints = synth.synthesize(
        held_object="cup of water",
        scene_objects=["laptop", "book"],
        spatial_relationships=["above", "under", "around"],
    )

    print(constraints.summary())

    # Verify spatial constraints
    unsafe_pairs = [(c.object_label, c.relationship) for c in constraints.S_r]
    assert ("laptop", "above") in unsafe_pairs, \
        f"Expected (laptop, above) in S_r, got {unsafe_pairs}"
    print("\n✓ Spatial: (laptop, above) correctly identified as unsafe")

    # Verify behavioral
    caution_map = {c.object_label: c.caution for c in constraints.S_b}
    assert caution_map.get("laptop") == "caution", \
        f"Expected caution for laptop, got {caution_map}"
    print("✓ Behavioral: laptop correctly flagged as caution")

    # Verify pose
    assert constraints.S_T.constraint_type == "constrained_rotation", \
        f"Expected constrained_rotation, got {constraints.S_T.constraint_type}"
    print("✓ Pose: cup of water correctly has constrained_rotation")

    print("\nAll assertions passed!\n")


def test_dry_sponge():
    """
    Test case: dry sponge should have few/no constraints.
    From the paper: sponge can go above laptop, can rotate freely.
    """
    print("=" * 60)
    print("TEST: Dry sponge → laptop scene")
    print("=" * 60)

    synth = VLMConstraintSynthesizer(use_mock=True, num_votes=3)

    constraints = synth.synthesize(
        held_object="dry sponge",
        scene_objects=["laptop", "book"],
        spatial_relationships=["above", "under", "around"],
    )

    print(constraints.summary())

    # Sponge should have free rotation
    assert constraints.S_T.constraint_type == "free_rotation", \
        f"Expected free_rotation for sponge, got {constraints.S_T.constraint_type}"
    print("\n✓ Pose: dry sponge correctly has free_rotation")

    # Sponge should have no spatial constraints (safe above laptop)
    assert len(constraints.S_r) == 0, \
        f"Expected no spatial constraints for sponge, got {len(constraints.S_r)}"
    print("✓ Spatial: dry sponge has no unsafe spatial relationships")

    print("\nAll assertions passed!\n")


def test_knife():
    """Test case: knife requires caution and constrained rotation."""
    print("=" * 60)
    print("TEST: Knife → general scene")
    print("=" * 60)

    synth = VLMConstraintSynthesizer(use_mock=True, num_votes=3)

    constraints = synth.synthesize(
        held_object="knife",
        scene_objects=["laptop", "book"],
        spatial_relationships=["above"],
    )

    print(constraints.summary())

    # Knife should have constrained rotation
    assert constraints.S_T.constraint_type == "constrained_rotation", \
        f"Expected constrained_rotation for knife, got {constraints.S_T.constraint_type}"
    print("\n✓ Pose: knife correctly has constrained_rotation")

    # Knife should require caution
    caution_flags = [c.caution for c in constraints.S_b]
    assert "caution" in caution_flags, \
        f"Expected caution for knife, got {caution_flags}"
    print("✓ Behavioral: knife correctly flagged as caution")

    print("\nAll assertions passed!\n")


def test_prompt_structure():
    """Verify the prompt templates match the paper's supplementary."""
    from config.prompts import (
        SPATIAL_SYSTEM_PROMPT,
        SPATIAL_FEW_SHOT_USER,
        SPATIAL_QUERY_TEMPLATE,
        BEHAVIORAL_QUERY_TEMPLATE,
        POSE_QUERY_TEMPLATE,
    )

    print("=" * 60)
    print("TEST: Prompt template structure")
    print("=" * 60)

    # Check system prompt
    assert "intelligent assistant" in SPATIAL_SYSTEM_PROMPT
    print("✓ System prompt contains expected text")

    # Check few-shot examples are present
    assert "dish of snacks" in SPATIAL_FEW_SHOT_USER
    assert "hot tea" in SPATIAL_FEW_SHOT_USER
    assert "phone_1" in SPATIAL_FEW_SHOT_USER
    print("✓ Spatial few-shot examples match paper")

    # Check template placeholders
    query = SPATIAL_QUERY_TEMPLATE.format(
        end_object="cup of water",
        scene_object="laptop",
        constraint_type="above",
    )
    assert "cup of water" in query
    assert "laptop" in query
    assert "above" in query
    print("✓ Spatial query template formats correctly")

    query_b = BEHAVIORAL_QUERY_TEMPLATE.format(
        end_object="cup of water",
        scene_object="laptop",
    )
    assert "quickly" in query_b
    assert "accelerate" in query_b
    print("✓ Behavioral query template formats correctly")

    query_p = POSE_QUERY_TEMPLATE.format(end_object="cup of water")
    assert "rotate" in query_p
    assert "collision - free" in query_p
    print("✓ Pose query template formats correctly")

    print("\nAll assertions passed!\n")


if __name__ == "__main__":
    test_prompt_structure()
    test_cup_of_water()
    test_dry_sponge()
    test_knife()
    print("=" * 60)
    print("ALL TESTS PASSED")
    print("=" * 60)
